import java.awt.*;

public class Rectangle extends Shapes
{
    private int x;
    private int y;
    private int length;
    private int height;
    private Color stroke_col;
    private Color button_col;

    public Rectangle(int x, int y, int length, int height, Color stroke_col, Color button_col)
    {
        this.x = x;
        this.y = y;
        this.length = length;
        this.height = height;
        this.stroke_col = stroke_col;
        this.button_col = button_col;
    }

    @Override
    public void draw(Graphics g)
    {
        g.setColor(stroke_col);
        g.fillRect(x, y, length, height);

        int innerButtonMargin = 3;
        g.setColor(button_col);
        g.fillRect(x + innerButtonMargin, y + innerButtonMargin, length - 2 * innerButtonMargin, height - 2 * innerButtonMargin);
    }
}
