import java.awt.*;

public abstract class Shapes {
    public abstract void draw(Graphics g);
}
